package factories;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import scripting.ClassCompiler;
import exceptions.ParameterListLengthException;
import actionModel.Action;
import actionModel.ActionMap;
import actionModel.ActionMethod;

/**
 * ActionFactory loads classes and parameter information for those classes from
 * actions.xml.
 * 
 * The classes themselves must be present in the Actions package of this
 * project. But they will be loaded dynamically at runtime. So, no operations
 * must be taken to add these classes to the runtime environment.
 * 
 * This code was developed with the help of and uses some code directly or
 * indirectly found in the tutorial on parsing xml found
 * here:http://www.java-samples.com/showtutorial.php?tutorialid=152
 * 
 * @author James Woods
 * 
 */
public class ActionFactory {

	public ActionMap makeActions(String filePath) {
		ActionMap toReturn = new ActionMap();

		// Set up the same reader that we used for the
		// GameObjectFactory.

		// Make a dom object to store parsing data.
		Document dom = null;

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			dom = db.parse(filePath);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		try {
			buildMap(toReturn, dom);
		} catch (ParameterListLengthException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return toReturn;
	}

	private void buildMap(ActionMap toReturn, Document dom)
			throws ParameterListLengthException {

		// get the root element
		Element docEle = dom.getDocumentElement();

		// get a nodelist of elements. We will be getting elements
		NodeList nl = docEle.getElementsByTagName("Action");

		if (nl != null && nl.getLength() > 0) {

			for (int i = 0; i < nl.getLength(); i++) {

				// get the game object element
				Element action = (Element) nl.item(i);

				// Get the type of action and class name for the action.
				String type = action.getAttribute("type");

				// This will be used to dynamically instantiate the class.
				String class_name = action.getAttribute("value");

				// Add the action to the ActionMap
				addToMap(toReturn, action, type, class_name);
			}
		}

	}

	private void addToMap(ActionMap toReturn, Element action, String type,
			String class_name) throws ParameterListLengthException {

		// Get the parameter node.
		NodeList nl = action.getElementsByTagName("Parameters");

		if (nl != null) {
			// Make sure there is only one parameter list in the class.
			if (nl.getLength() == 1) {

				// get the action element
				Element parameters = (Element) nl.item(0);

				toReturn.add(type, getAction(parameters, class_name, type));

			} else
				// If there is an incorrect number of parameter lists throw an
				// exception.
				throw new ParameterListLengthException(type, class_name,
						nl.getLength());
		}

	}

	private Action getAction(Element parameters, String class_name, String type) {
		// Build the parameter list for the action.
		String[] params = getParamValues(parameters);

		// Get the Method object for the class.
		ActionMethod method = getMethod(class_name, type);

		// Return the action.
		return new Action(params, method);
	}

	/**
	 * This method invokes methods on the ClassLoader to instantiate the class
	 * with the given class_name dynamically.
	 * 
	 * This code was created with the help of and may directly or indirectly
	 * contain code that can be found
	 * here:http://tutorials.jenkov.com/java-reflection
	 * /dynamic-class-loading-reloading.html
	 * 
	 * @param class_name
	 * @param type
	 *            the type of the class, also the package containing the class.
	 * @return the Method object containing the class object with the given
	 *         name.
	 */
	private ActionMethod getMethod(String class_name, String type) {
//
//		// Get the class loader for the ActionFactory.
//		ClassLoader classLoader = ActionFactory.class.getClassLoader();
		

		ActionMethod toReturn = null;

		try {
			
			//Build the class.
			ClassCompiler compiler = new ClassCompiler();
			compiler.compile("Scripts/lib/*", "Scripts/" + type + "/" + class_name+ ".java");
			
			URLClassLoader classLoader = new URLClassLoader(new URL[]{new File("Scripts/" + type + "/").toURI().toURL()});
			//Load the given class of the given type.
			toReturn = (ActionMethod) classLoader.loadClass(class_name)
					.newInstance();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return toReturn;
	}

	private String[] getParamValues(Element parameter) {
		// Get the parameter list from the xml.
		Node toAdd = parameter.getFirstChild();
		
		String list = "";
		
		if(toAdd != null)
			list = toAdd.getNodeValue();

		// Break the parameter list into individual parts at the commas.
		String[] toReturn = list.split(", ");

		// Trim off any extra spaces.
		for (String toFormat : toReturn)
			toFormat = toFormat.trim();

		return toReturn;
	}
}
