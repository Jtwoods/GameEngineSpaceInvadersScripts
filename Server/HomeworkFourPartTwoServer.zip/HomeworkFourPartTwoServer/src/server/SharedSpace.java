package server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

import objectModel.ObjectMap;
import eventModel.Event;
import eventModel.EventHandler;
import eventModel.EventManager;
import eventModel.EventParameter;
import eventModel.ObjectParameter;

public class SharedSpace {

	private EventManager eManager;
	private ObjectMap map;

	public SharedSpace(ObjectMap objects) {
		eManager = EventManager.getManager();
		map = objects;
	}

	// /**
	// *
	// * @param toDraw
	// */
	// public void updateObjects(ObjectMap toDraw) {
	// synchronized(this) {
	// map = toDraw;
	// }
	// }

	/**
	 * Removes the game object from the object model.
	 * 
	 * @param gUID
	 *            the guid of the game object to be removed.
	 */
	public void remove(String gUID) {
		map.remove(gUID);
	}

	/**
	 * Adds the events to the event map.
	 * 
	 * @param toAdd
	 *            the map of events.
	 */
	public void addEvents(PriorityQueue<Event> toAdd) {
		eManager.addAllEvents(toAdd);
	}

	/**
	 * returns the object map.
	 * 
	 * @return
	 */
	public ObjectMap getObjects() {
		return map;
	}

	/**
	 * Adds a new player character with the given guid.
	 * 
	 * @param gUID
	 */
	public void addPlayer(String gUID) {
		// We will create a spawnNew event and handle character creation
		// and spawning with a script.
		// Create object parameters for the player.
		ObjectParameter pOne = new ObjectParameter();
		pOne.GUID = gUID;

		// Create a Spawn event parameter.
		EventParameter param = new EventParameter();
		param.objectParameters.add(pOne);

		param.additional = new Object[1];

		// Add the time with an additional elapsed time to wait before spawning.
		param.additional[0] = (double)300.0;

		// Add the event to the EventManager's queue.
		Event spawn_new = new Event("SpawnNew", param);
		spawn_new.priority = 0;
		eManager.addEvent(new Event("SpawnNew", param));
	}

}
