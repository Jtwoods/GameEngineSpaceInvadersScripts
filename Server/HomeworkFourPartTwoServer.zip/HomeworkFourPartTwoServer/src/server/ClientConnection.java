package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Is a wrapper that holds the client connections for the given client
 * and controls the outward and inward flow of events and game objects 
 * to and from the server.
 * 
 * @author James Woods
 * 
 */
public class ClientConnection {

	public ObjectOutputStream out;
	public ObjectInputStream in;
	public Socket client;
	
	//This is the GUID for the client player's object.
	public String GUID;

	public ClientConnection(Socket client, String guid) throws IOException {
		this.client = client;

		// Establish input and output streams for the client.
		// Output.
		out = new ObjectOutputStream(client.getOutputStream());
		in = new ObjectInputStream(client.getInputStream());
		
		//Need to get the GUID of the player here.
		GUID = guid;
		
		
	}

}
