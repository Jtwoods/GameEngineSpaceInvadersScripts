package server;

import factories.GameObjectFactory;
import homeworkFourPartTwoServer.HomeworkFourPartTwoServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import time.TimeManager;


/**
 * ConnectionServlet will get client connections and add them to the game in progress.
 * 
 * @author James Woods
 * 
 */
public class ConnectServlet implements Runnable {

	private ServerSocket server;
	private HomeworkFourPartTwoServer parent;
	private ClientResourcesServlet connections;
	private GameObjectFactory oFactory;

	public ConnectServlet(HomeworkFourPartTwoServer parent, ClientResourcesServlet connections) {
		this.parent = parent;
		this.connections = connections;
		this.oFactory = GameObjectFactory.getFactory();
	}

	@Override
	public void run() {

		try {
			// Instantiate a listening ServerSocket at port 5001.
			server = new ServerSocket(5001);

			// Continue accepting until flagged.
			while (parent.running) {
				// Listen at port 5001 and accept clients.
				Socket toAdd = server.accept();
				
				//Get a GUID for the new player.
				String guidToAdd = oFactory.getGUID();

				synchronized (parent) {
					// Create a ClientConnections object with the new
					// client.
					ClientConnection connection = new ClientConnection(
							toAdd, guidToAdd);
					
					//Send the client their new GUID.
					Object[] toSend = new Object[2];
					toSend[0] = guidToAdd;
					toSend[1] = TimeManager.getManager();
					connection.out.writeObject(toSend);

					// Add the new client to the clients list.
					connections.add(connection);
				}

			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}
