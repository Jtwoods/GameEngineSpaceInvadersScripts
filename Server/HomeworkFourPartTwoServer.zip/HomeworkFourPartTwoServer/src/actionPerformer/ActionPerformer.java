package actionPerformer;

import java.util.ArrayList;
import java.util.concurrent.locks.Lock;

import objectModel.ObjectMap;
import objectModel.Property;
import synchronization.ReQueueableIterator;
import exceptions.NullArgumentException;
import actionModel.Action;
import actionModel.ActionMap;
import actionModel.ActionMethod;
import actionModel.ActionParameter;

/**
 * The ActionPerformer class performs as the pipeline for the given action type
 * in this Property-centric game engine. Basically, it matches all loaded Method
 * objects with the parameters needed to perform their invoke method.
 * 
 * @author James Woods
 * 
 */
public class ActionPerformer {

	private String type;
	private int iteratorNumber;

	public ActionPerformer(String type) {
		this.type = type;
		if ("Physics".equals(type))
			iteratorNumber = 1;
		else
			iteratorNumber = 0;
	}

	/**
	 * run performs all loaded Actions of the type for this performer on all
	 * objects that they apply to.
	 * 
	 * @param actionMap
	 *            the map containing all actions.
	 * @param objectMap
	 *            the map containing all objects.
	 */
	public void run(ActionMap actionMap, ObjectMap objectMap, double time) {
		// Get the list of actions for the type of this performer.
		ArrayList<Action> actions = actionMap.get(type);

		if (actions != null) {

			try {

				// For all actions in the list of this type build the needed
				// parameter for the method and call invoke.
				for (Action action : actions) {

					// Get the list of parameters for the action.
					String[] params = action.getParameters();

					// Get the method to be invoked.
					ActionMethod toCall = action.getMethod();

					// Get the list of objects that have defined parameter for
					// this
					// class name.
					Property toUse = objectMap.get(toCall.getName());

					// If toUse is null then no one is registered for this
					// action.
					// Skip it.
					if (toUse != null) {

						Iterable<String> iter = objectMap.GUIDS
								.getUnlockedIterator();

						// For each object.
						for (String GUID : iter) {

							// Check to see if this object uses this
							// action.
							Object[] toCheck = toUse.getParameters(GUID);

							// If this is not null we should perform the
							// action
							// on
							// this
							// object.
							if (toCheck != null) {

								// Build the parameters for the method.
								ActionParameter parameter;
								try {
									parameter = buildParameters(GUID,
											objectMap, params);

									// If the parameter list exists for
									// the
									// object
									// perform the operation.
									if (parameter != null) {
										// Add the class name to the
										// parameter.
										parameter.class_name = toCall.getName();
										// Add the time to the
										// parameter.
										parameter.time = time;

										// Add the GUID to the
										// parameter.
										parameter.GUID = GUID;

										// Call invoke on the Method
										// object.
										parameter = toCall.invoke(parameter);

										// Store the updated state of
										// the
										// parameters.
										saveParameters(GUID, objectMap, params,
												parameter);

									}
								} catch (NullArgumentException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}

						}
					}

				}

			} catch (NullArgumentException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	private void saveParameters(String GUID, ObjectMap objectMap,
			String[] params, ActionParameter parameter) {
		synchronized (objectMap) {
			for (int i = 0; i < params.length; i++) {
				if (!"ObjectMap".equals(params[i])) {
					try {
						Property toUpdate = objectMap.get(params[i]);
						toUpdate.updateParameterList(GUID,
								(Object[]) parameter.properties.get(i));
						objectMap.add(toUpdate.getType(), toUpdate);
					} catch (NullArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}

	}

	private ActionParameter buildParameters(String GUID, ObjectMap objectMap,
			String[] params) throws NullArgumentException {

		ActionParameter toReturn = new ActionParameter();

		ArrayList<Object[]> toAdd = new ArrayList<Object[]>();

		for (int i = 0; i < params.length; i++) {

			if ("ObjectMap".equals(params[i])) {
				Object[] objects = new Object[1];
				objects[0] = objectMap;
				toAdd.add(i, objects);
			} else {
				Property toGet = objectMap.get(params[i]);

				if (toGet == null)
					return null;

				Object[] objectParams = toGet.getParameters(GUID);

				if (objectParams == null)
					return null;

				toAdd.add(i, objectParams);
			}
		}

		toReturn.properties = toAdd;
		toReturn.parameterList = params;

		return toReturn;
	}
}
