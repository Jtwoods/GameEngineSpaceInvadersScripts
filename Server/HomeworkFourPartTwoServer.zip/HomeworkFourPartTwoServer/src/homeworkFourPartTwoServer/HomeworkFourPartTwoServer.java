package homeworkFourPartTwoServer;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import objectModel.ObjectMap;
import objectModel.Property;
import eventModel.Event;
import eventModel.EventManager;
import eventModel.EventMap;
import eventModel.EventParameter;
import eventModel.ObjectParameter;
import exceptions.NullArgumentException;
import factories.ActionFactory;
import factories.EventFactory;
import factories.GameObjectFactory;
import actionModel.ActionMap;
import actionPerformer.ActionPerformer;
import processing.core.PApplet;
import processing.core.PImage;
import server.ClientResourcesServlet;
import server.ConnectServlet;
import server.SharedSpace;
import time.TimeManager;

public class HomeworkFourPartTwoServer extends PApplet {

	private TimeManager tManager;

	// These are the various maps and threads for the AI, Physics, and event
	// management.
	public ObjectMap objects;
	public ActionMap actions;
	private EventMap events;
	public ActionPerformer physics;
	private ActionPerformer ai;
	private EventManager eManager;
	private Thread physThread;
	private Thread AIThread;
	private Thread eventThread;
	private HashMap<String, PImage> images;

	// Shared space for client data processing.
	protected SharedSpace shared;

	// A flag that lets the servlet know when to stop.
	public boolean running;

	private String playerGUID = "SomethingMoving";

	private Thread serverObjectIOThread;
	private Thread serverConnectionsThread;
	private ClientResourcesServlet connections;

	public void setup() {

		// Set the server flag.
		running = true;

		// Instantiate the hash map of images
		// that will be used to store loaded images.
		images = new HashMap<String, PImage>();

		// Build the ObjectMap.
		GameObjectFactory oFactory = GameObjectFactory.getFactory();
		objects = oFactory.makeObjects("gameobjects.xml");

		// Build the ActionMap.
		ActionFactory aFactory = new ActionFactory();
		actions = aFactory.makeActions("actions.xml");

		// Build the EventMap.
		EventFactory eFactory = new EventFactory();
		events = eFactory.makeEvents("events.xml");

		// Create a Physics ActionPerformer.
		physics = new ActionPerformer("Physics");

		// Create an AI ActionPerfromer.
		ai = new ActionPerformer("AI");

		// Get the singleton EventManager.
		eManager = EventManager.getManager();
		// Set the event map.
		eManager.setEventMap(events);

		// Set the time manager.
		tManager = TimeManager.getManager();

		// Set the size of the display and the frame rate.
		size(1000, 600);
		frameRate(60);

		// Create the sharedSpace.
		shared = new SharedSpace(objects);

		// Start the listening server and the data transfer server.
		serverObjectIOThread = new Thread();
		serverObjectIOThread.start();

		connections = new ClientResourcesServlet(shared);

		serverConnectionsThread = new Thread(new ConnectServlet(this,
				connections));
		serverConnectionsThread.start();

	}

	public void keyPressed() {

		// Build an event parameter with
		// The key press as additional information.
		EventParameter param = new EventParameter();
		param.additional = new Object[2];
		param.additional[0] = keyCode;
		param.additional[1] = key;

		ObjectParameter obj = new ObjectParameter();
		obj.parameterList = new String[2];
		obj.parameterList[0] = "MovingRight";
		obj.parameterList[1] = "MovingLeft";

		obj.GUID = playerGUID;

		param.objectParameters.add(obj);

		// Now build the event and add it to the EventManager queue.
		eManager.addEvent(new Event("KeyPressed", param));

	}

	public void keyReleased() {

		// Build an event parameter with
		// The key press as additional information.
		EventParameter param = new EventParameter();
		param.additional = new Object[2];
		param.additional[0] = keyCode;
		param.additional[1] = key;

		ObjectParameter obj = new ObjectParameter();
		obj.parameterList = new String[2];
		obj.parameterList[0] = "MovingRight";
		obj.parameterList[1] = "MovingLeft";

		obj.GUID = playerGUID;

		param.objectParameters.add(obj);

		// Now build the event and add it to the EventManager queue.
		eManager.addEvent(new Event("KeyReleased", param));

	}

	public void draw() {

		synchronized (this) {
			tManager.startFrame();
		}
		ObjectMap toDraw = null;

		synchronized (objects.GUIDS) {

			physThread = new Thread(new PhysOperation(actions, objects,
					tManager.frameTime()));
			physThread.start();

			// Join with the physics thread.
			try {
				physThread.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// Now we can copy the freshly updated objects to be used for
			// rendering and get ready to pass them to the clients.
			toDraw = objects.clone();

		}

		// Start rendering.

		// Clear the screen and draw the background.
		clear();
		background(204);

		// Rendering will be hard coded to allow use of the
		// PApplet. Animation can be scripted by updating the
		// Representation property with event handlers or general scripts.
		try {

			Property positions = toDraw.get("Position");
			Property representation = toDraw.get("Representation");
			Property bounds = toDraw.get("BoundingBox");
			Property colors = toDraw.get("Color");

			for (String guid : objects.GUIDS.getUnlockedIterator()) {
				Object[] pos = positions.getParameters(guid);
				Object[] string = representation.getParameters(guid);
				Object[] rect = bounds.getParameters(guid);
				Object[] hue = colors.getParameters(guid);

				if (pos != null) {

					float Xpos = (float) pos[0];
					float Ypos = (float) pos[1];

					Rectangle box = null;

					if (rect != null)
						box = (Rectangle) rect[0];

					int color[] = new int[3];
					color[0] = 0;
					color[1] = 0;
					color[2] = 255;

					if (hue != null) {
						color[0] = (int) hue[0];
						color[1] = (int) hue[1];
						color[2] = (int) hue[2];
					}

					PImage image = null;

					// We will memoize the images as they are loaded the
					// first time.
					if (string != null) {
						if (images.containsKey((String) string[0])) {
							image = images.get((String) string[0]);
						} else {
							image = loadImage((String) string[0]);
							images.put((String) string[0], image);
						}
					}

					pushMatrix();
					if (image != null && box != null) {
						fill(color[0], color[1], color[2]);
						ellipse(Xpos, Ypos, box.height, box.width);
						image(image, (float) (Xpos - box.width * .5f),
								(float) (Ypos - box.height * .5f));
					} else if (box != null) {
						fill(color[0], color[1], color[2]);
						rect(Xpos - box.width * .5f, Ypos - box.height * .5f,
								box.width, box.height);
					}
					popMatrix();

				}

			}

		} catch (NullArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Send and receive from the clients.
		serverObjectIOThread = new Thread(connections);
		serverObjectIOThread.start();

		// Wait for the clients to finish.
		try {
			serverObjectIOThread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		eventThread = new Thread(new EventOperation());
		eventThread.start();

		try {
			eventThread.join();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		tManager.endFrame(toDraw);

	}

	/**
	 * Stop runs when the PApplet is stopped and provides the cleanup for the
	 * server.
	 */
	public void stop() {
		running = false;
	}

	private class PhysOperation implements Runnable {

		private ActionMap actions;
		private ObjectMap objects;
		private double time;

		public PhysOperation(ActionMap actions, ObjectMap objects, double time2) {
			this.actions = actions;
			this.objects = objects;
			this.time = time2;
		}

		@Override
		public void run() {
			physics.run(actions, objects, time);
		}

	}

	private class AIOperation implements Runnable {

		private ActionMap actions;
		private ObjectMap objects;
		private double time;

		public AIOperation(ActionMap actions, ObjectMap objects, double time2) {
			this.actions = actions;
			this.objects = objects;
			this.time = time2;
		}

		@Override
		public void run() {
			ai.run(actions, objects, time);
		}

	}

	private class EventOperation implements Runnable {

		@Override
		public void run() {
			eManager.manageEvents(objects);
		}

	}

	public static void main(String[] args) {
		PApplet.main(new String[] { HomeworkFourPartTwoServer.class.getName() });
	}

}
