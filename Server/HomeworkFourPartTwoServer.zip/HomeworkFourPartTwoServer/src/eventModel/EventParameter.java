package eventModel;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * EventParameter is a wrapper that contains 
 * parameters for objects that have caused an event
 * or other information that might be needed to
 * perform event handling.
 * @author James Woods
 *
 */
public class EventParameter implements Serializable{
	
	/**
	 * A list of ObjectParameters. 
	 */
	public ArrayList<ObjectParameter> objectParameters;
	public Object[] additional;
	
	public EventParameter() {
		objectParameters = new ArrayList<ObjectParameter>();
	}
}
