package eventModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;

import objectModel.ObjectMap;
import objectModel.Property;
import time.TimeManager;
import exceptions.NullArgumentException;
import actionModel.ActionParameter;

/**
 * This is a singleton manager that will perform registration of event handlers,
 * provide an event queue and will provide event handling.
 * 
 * @author James Woods
 * 
 */
public class EventManager {

	private static PriorityQueue<Event> events;
	private static EventMap eMap;
	private static EventManager manager;

	/**
	 * private constructor for the EventManager.
	 */
	private EventManager() {
		eMap = new EventMap();
		events = new PriorityQueue<Event>();
	}

	/**
	 * sets the EventeMap used by this EventManager.
	 * 
	 * @param eMap
	 *            the new EventeMap.
	 */
	public void setEventMap(EventMap eMap) {
		this.eMap = eMap;
	}

	/**
	 * gets the one and only instance of this class.
	 * 
	 * @return the EventManager.
	 */
	public static EventManager getManager() {
		if (manager == null)
			manager = new EventManager();
		return manager;
	}

	/**
	 * registers the given EventHandler for the given event type.
	 * 
	 * @param type
	 *            the type of the event.
	 * @param handler
	 *            the EventHandler for the event of the given type.
	 */
	public void register(int type, EventHandler handler) {
		eMap.add(type, handler);
	}

	/**
	 * adds the given Event to the event queue.
	 * 
	 * @param event
	 */
	public void addEvent(Event event) {
		// Set the time_stamp for this event.
		event.time_stamp = TimeManager.getManager().currentTimeInStep();
		synchronized (events) {
			events.add(event);
		}
	}

	/**
	 * removes and returns the highest prioritized event.
	 * 
	 * @return the event.
	 */
	public Event getEvent() {
		Event toReturn = null;
		synchronized (events) {
			toReturn = events.remove();
		}
		return toReturn;
	}

	/**
	 * iterates through the queued events and performs the EventManager actions
	 * for each.
	 */
	public void manageEvents(ObjectMap oMap) {
		// Save the events in a queue for calculations.
		PriorityQueue<Event> toCalc = new PriorityQueue<Event>();
		synchronized (events) {
			toCalc.addAll(events);
		}
		// Save the events in a queue that will be saved.
		PriorityQueue<Event> toStore = new PriorityQueue<Event>();
		synchronized (events) {
			toStore.addAll(events);
		}

		// Add the events to the time manager.
		TimeManager tManager = TimeManager.getManager();
		tManager.setStepEvents(toStore);

		// Create a new event queue.
		synchronized (events) {
			events = new PriorityQueue<Event>();
		}
		synchronized (toCalc) {
			while (toCalc.size() > 0) {
				Event event = (Event) toCalc.remove();

				ArrayList<EventHandler> handlers = eMap.getHandlers(event
						.getType());
				for (EventHandler handler : handlers) {
					EventMethod method = handler.getMethod();
					EventParameter params = event.getParams();
					for (int i = 0; i < params.objectParameters.size(); i++) {
						ObjectParameter currentParam = params.objectParameters
								.get(i);
						try {
							currentParam = buildParameters(currentParam.GUID,
									oMap, method.signature);
							params.objectParameters.set(i, currentParam);
						} catch (NullArgumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					EventParameter returned = method.invoke(event.getParams());

					for (int i = 0; i < returned.objectParameters.size(); i++) {
						saveParameters(returned.objectParameters.get(i), oMap);
					}
				}
			}
		}
	}

	private void saveParameters(ObjectParameter objectParameter, ObjectMap oMap) {
		synchronized (oMap) {
			if (objectParameter != null
					&& objectParameter.parameterList != null) {
				for (int i = 0; i < objectParameter.parameterList.length; i++) {
					if (!"ObjectMap".equals(objectParameter.parameterList[i])) {
						try {
							Property toUpdate = oMap
									.get(objectParameter.parameterList[i]);

							toUpdate.updateParameterList(objectParameter.GUID,
									(Object[]) objectParameter.properties
											.get(i));
							oMap.add(toUpdate.getType(), toUpdate);
						} catch (NullArgumentException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	private ObjectParameter buildParameters(String GUID, ObjectMap objectMap,
			String[] params) throws NullArgumentException {

		ObjectParameter toReturn = new ObjectParameter();

		ArrayList<Object[]> toAdd = new ArrayList<Object[]>();

		for (int i = 0; i < params.length; i++) {

			if ("ObjectMap".equals(params[i])) {
				Object[] objects = new Object[1];
				objects[0] = objectMap;
				toAdd.add(i, objects);
			} else {
				Property toGet = objectMap.get(params[i]);

				if (toGet == null)
					return null;

				Object[] objectParams = toGet.getParameters(GUID);

				if (objectParams == null)
					return null;

				toAdd.add(i, objectParams);
			}
		}

		toReturn.properties = (ArrayList<Object[]>) toAdd;
		toReturn.parameterList = params;
		toReturn.GUID = GUID;

		return toReturn;
	}

	/**
	 * adds the events to the event queue.
	 * 
	 * @param toAdd
	 *            the event queue to be added.
	 */
	public void addAllEvents(PriorityQueue<Event> toAdd) {
		if (toAdd != null)
			events.addAll(toAdd);
	}

	/**
	 * Clears the events queue.
	 */
	public PriorityQueue<Event> purgeQueue() {
		PriorityQueue<Event> toReturn = new PriorityQueue<Event>();
		toReturn.addAll(events);
		events.clear();
		return toReturn;
	}

}
