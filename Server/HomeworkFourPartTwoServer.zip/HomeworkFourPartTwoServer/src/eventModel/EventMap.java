package eventModel;

import java.util.ArrayList;
import java.util.HashMap;

public class EventMap {
	
	private HashMap<Integer, ArrayList<EventHandler>> map;

	
	public EventMap() {
		map = new HashMap<Integer, ArrayList<EventHandler>>();
	}
	
	/**
	 * add places the handler in the map with the type as the key.
	 * @param type the type of event this will handle.
	 * @param handler the EventHandler that will handle the given event type.
	 */
	public void add(int type, EventHandler handler) {
		//Get the list of handlers.
		ArrayList<EventHandler> toUpdate = map.get(type);
		
		//If the handler list does not exist create one.
		if(toUpdate == null)
			toUpdate = new ArrayList<EventHandler>();
		
		//Add the event handler to the list and put it in the map.
		toUpdate.add(handler);
		
		map.put(type, toUpdate);
	}

	public ArrayList<EventHandler> getHandlers(int type) {
		return map.get(type);
	}
	
}
