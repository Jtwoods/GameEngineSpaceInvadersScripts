package eventModel;

import eventModel.EventMethod;

public class EventHandler {

	// This is a list of parameters that are needed by the Method
	// to perform its action on game objects. Note: GameObjects
	// that do not have the required parameters will be excluded
	// from the given action.
	private String[] parameters;

	// This is an interface handle for the dynamically loaded
	// class that will perform the action.
	private EventMethod action;

	public EventHandler(String[] params, EventMethod action) {
		this.action = action;
		this.parameters = params;
	}

	/**
	 * returns the Method interface for this Event.
	 * 
	 * @return the Method interface.
	 */
	public EventMethod getMethod() {
		return action;
	}

	/**
	 * sets the Method for this Event.
	 * 
	 * @param action
	 * @return
	 */
	public void setMethod(EventMethod action) {
		this.action = action;
	}

	/**
	 * returns the parameter list for the Event.
	 * 
	 * @return array of parameter names.
	 */
	public String[] getParameters() {
		return parameters;
	}

	/**
	 * sets the parameter list for this Event.
	 * 
	 * @param parameters
	 */
	public void setParameters(String[] parameters) {
		this.parameters = parameters;
	}
}
