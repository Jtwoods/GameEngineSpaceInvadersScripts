package exceptions;

public class NullArgumentException extends Exception {
	public NullArgumentException(String arg) {
		super(arg);
	}
}
