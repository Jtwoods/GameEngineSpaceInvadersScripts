package factories;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import scripting.ClassCompiler;
import actionModel.ActionMethod;
import eventModel.EventHandler;
import eventModel.EventMap;
import eventModel.EventMethod;
import exceptions.ParameterListLengthException;

/**
 * EventFactory loads classes and parameter information for those classes from
 * events.xml.
 * 
 * The classes themselves must be present in the Events package of this
 * project. But they will be loaded dynamically at runtime. So, no operations
 * must be taken to add these classes to the runtime environment.
 * 
 * This code was developed with the help and uses some code directly or
 * indirectly found in the tutorial on parsing xml found
 * here:http://www.java-samples.com/showtutorial.php?tutorialid=152
 * 
 * @author James Woods
 * 
 */
public class EventFactory {

	public EventMap makeEvents(String filePath) {
		EventMap toReturn = new EventMap();

		// Set up the same reader that we used for the
		// GameObjectFactory.

		// Make a dom object to store parsing data.
		Document dom = null;

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			dom = db.parse(filePath);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		try {
			buildMap(toReturn, dom);
		} catch (ParameterListLengthException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return toReturn;
	}

	private void buildMap(EventMap toReturn, Document dom)
			throws ParameterListLengthException {

		// get the root element
		Element docEle = dom.getDocumentElement();

		// get a nodelist of elements. We will be getting elements
		NodeList nl = docEle.getElementsByTagName("Event");

		if (nl != null && nl.getLength() > 0) {

			for (int i = 0; i < nl.getLength(); i++) {

				// get the game object element
				Element event = (Element) nl.item(i);

				// Get the type of event and class name for the event.
				String type = event.getAttribute("type");

				// This will be used to dynamically instantiate the class.
				String class_name = event.getAttribute("value");

				// Add the event to the EventMap
				addToMap(toReturn, event, type, class_name);
			}
		}

	}

	private void addToMap(EventMap toReturn, Element event, String type,
			String class_name) throws ParameterListLengthException {

		// Get the parameter node.
		NodeList nl = event.getElementsByTagName("Parameters");

		if (nl != null) {
			// Make sure there is only one parameter list in the class.
			if (nl.getLength() == 1) {

				// get the event element
				Element parameters = (Element) nl.item(0);

				toReturn.add(type.hashCode(), getEvent(parameters, class_name, type));

			} else
				// If there is an incorrect number of parameter lists throw an
				// exception.
				throw new ParameterListLengthException(type, class_name,
						nl.getLength());
		}

	}

	private EventHandler getEvent(Element parameters, String class_name, String type) {
		// Build the parameter list for the event.
		String[] params = getParamValues(parameters);

		// Get the Method object for the class.
		EventMethod method = getMethod(class_name, type);

		// Return the event.
		return new EventHandler(params, method);
	}

	/**
	 * This method invokes methods on the ClassLoader to instantiate the class
	 * with the given class_name dynamically.
	 * 
	 * This code was created with the help of and may directly or indirectly
	 * contain code that can be found
	 * here:http://tutorials.jenkov.com/java-reflection
	 * /dynamic-class-loading-reloading.html
	 * 
	 * @param class_name
	 * @param type
	 *            the type of the class, also the package containing the class.
	 * @return the Method object containing the class object with the given
	 *         name.
	 */
	private EventMethod getMethod(String class_name, String type) {


		EventMethod toReturn = null;

		try {
			
			//Build the class.
			ClassCompiler compiler = new ClassCompiler();
			
			compiler.compile("Scripts/lib/*", "Scripts/Events/" + class_name + ".java");
			
			URLClassLoader classLoader = new URLClassLoader(new URL[]{new File("Scripts/Events/").toURI().toURL()});
			//Load the given class of the given type.
			toReturn = (EventMethod) classLoader.loadClass(class_name)
					.newInstance();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return toReturn;
	}

	private String[] getParamValues(Element parameter) {
		// Get the parameter list from the xml.
		// If the string is empty we should get an exception here.
		String list = parameter.getFirstChild().getNodeValue();

		// Break the parameter list into individual parts at the commas.
		String[] toReturn = list.split(", ");

		// Trim off any extra spaces.
		for (String toFormat : toReturn)
			toFormat = toFormat.trim();

		return toReturn;
	}
}

