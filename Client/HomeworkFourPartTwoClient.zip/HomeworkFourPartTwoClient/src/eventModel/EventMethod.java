package eventModel;

import eventModel.EventParameter;

public abstract class EventMethod {

	/**
	 * signature is the parameter signature for this Method. This should be
	 * instantiated and filled out by children of this class. This is how your
	 * Method class will request and verify parameters from the game engine.
	 */
	protected String[] signature;

	public abstract String getName();

	public abstract EventParameter invoke(EventParameter params);

}
