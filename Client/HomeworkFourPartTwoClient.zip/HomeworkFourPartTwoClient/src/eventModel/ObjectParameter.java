package eventModel;

import java.io.Serializable;
import java.util.ArrayList;

public class ObjectParameter implements Serializable {
	public String GUID;
	public ArrayList<Object[]> properties;
	public String[] parameterList;
	
	public ObjectParameter() {
		properties = new ArrayList<Object[]>();
	}
}
