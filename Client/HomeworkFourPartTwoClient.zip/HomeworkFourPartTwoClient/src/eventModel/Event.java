package eventModel;

import java.io.Serializable;

public class Event implements Serializable, Comparable {
	
	private static final double TIME_VARIATION = 1;
	public int priority;
	private int type;
	private EventParameter params;
	public double time_stamp;
	
	public Event(String type, EventParameter params) {
		this.setType(type.hashCode());
		this.setParams(params);
		this.priority = Integer.MAX_VALUE;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public EventParameter getParams() {
		return params;
	}

	public void setParams(EventParameter params) {
		
		this.params = params;
	}

	@Override
	public int compareTo(Object o) {
		if(Math.abs(this.time_stamp - ((Event)o).time_stamp) <= TIME_VARIATION)
			return this.priority - ((Event)o).priority;
		return (int)(this.time_stamp - ((Event)o).time_stamp);
	}
	
	public Event clone() {
		Event toReturn = new Event("None", this.params);
		toReturn.type = this.type;
		toReturn.priority = this.priority;
		toReturn.time_stamp = this.time_stamp;
		return toReturn;
	}
}
