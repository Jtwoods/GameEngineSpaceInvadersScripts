package scripting;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public class ClassCompiler {
	private JavaCompiler compiler;
	
	public ClassCompiler() {
		compiler = ToolProvider.getSystemJavaCompiler();
	}

	//Code borrowed from:http://stackoverflow.com/questions/12173294/compiling-fully-in-memory-with-javax-tools-javacompiler
	public void compile(String path, String src) {
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		int result = compiler.run(null, null, null, src);
	}
}
