package actionModel;

/**
 * Action helps perform actions on game objects.
 * To do this Action stores a list of parameters
 * needed by the Action to be performed and a class
 * object that implements the Modifier interface.
 * 
 * These Modifier classes will be loaded at runtime 
 * by the ActionFactory from information found in 
 * the actions.xml document. 
 * 
 * @author James Woods
 *
 */
public class Action {
	
	//This is a list of parameters that are needed by the Method 
	//to perform its action on game objects. Note: GameObjects 
	//that do not have the required parameters will be excluded
	//from the given action.
	private String[] parameters;

	
	//This is an interface handle for the dynamically loaded
	//class that will perform the action.
	private ActionMethod action;
	
	public Action(String[] params, ActionMethod action) {
		this.action = action;
		this.parameters = params;
	}
	
	/**
	 * returns the Method interface for this Action.
	 * @return the Method interface.
	 */
	public ActionMethod getMethod() {
		return action;
	}
	
	/**
	 * sets the Method for this Action.
	 * @param action
	 * @return 
	 */
	public void setMethod(ActionMethod action) {
		this.action = action;
	}
	
	/**
	 * returns the parameter list for the Action.
	 * @return array of parameter names.
	 */
	public String[] getParameters() {
		return parameters;
	}
	
	/**
	 * sets the parameter list for this Action.
	 * @param parameters
	 */
	public void setParameters(String[] parameters) {
		this.parameters = parameters;
	}
	

}
